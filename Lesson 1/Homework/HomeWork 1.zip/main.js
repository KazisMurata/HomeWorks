let userName = prompt('What is your name?', '');

let userAge = prompt('What year were you born?', '');

userAge = 2019 - userAge;

alert(`Nice to meet you ${userName}, ${userAge} years old!`);

// alert('Nice to meet you ' + userName + ', ' + userAge + ' years old!');

